library(nlmixr)
options(keep.source = TRUE)
if(!exists("PBPK_data", envir=.GlobalEnv)) {
  if(file.exists("./data/PBPK_data.rds")){
    data_nlm <- readRDS("./data/PBPK_data.rds")
  }else if(file.exists("./data/PBPK_data.csv")){
    data_nlm <- read.csv("./data/PBPK_data.csv")
  }
}else{
  data_nlm <- PBPK_data
}
source("/Users/richard/Documents/Rpackages/shinyMixR/Case2.Page/shinyMixRSolution/models/run1.r")
setwd("shinyMixR/temp")
modres <- try(nlmixr(run1, data=data_nlm, est="saem",control= saemControl(n.burn=100, n.em=100)))

if(length(class(modres))>1 && class(modres)!="try-error"){
  saveRDS(modres,file="../run1.res.rds")
  saveRDS(list(OBJF=modres$objective,partbl=modres$par.fixed,omega=modres$omega,
               tottime=rowSums(modres$time)),file="../run1.ressum.rds")
}


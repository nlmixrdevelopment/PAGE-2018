# nlmixr course PAGE2018
# Case Example 2: PBPK
# Author: Wenping Wang
# This script shows the various ways of running and analysing the case model.

# PART 1. RUNNING THE MODEL

# ------------------------
# 1. Using nlmixr directly 
library(nlmixr)

# define the model
pbpk <- function(){
  ini({
    ##theta=exp(c(1.1, .3, 2, 7.6, .003, .3))
    lKbBR = 1.1
    lKbMU = 0.3
    lKbAD = 2
    lCLint = 7.6
    lKbBO = 0.03
    lKbRB = 0.3
    eta.LClint ~ 4
    add.err <- 1
  })
  model({
    KbBR = exp(lKbBR)
    KbMU = exp(lKbMU)
    KbAD = exp(lKbAD)
    CLint= exp(lCLint + eta.LClint)
    KbBO = exp(lKbBO)
    KbRB = exp(lKbRB)
    
    ## Regional blood flows
    CO  = (187.00*WT^0.81)*60/1000;         # Cardiac output (L/h) from White et al (1968)
    QHT = 4.0 *CO/100;
    QBR = 12.0*CO/100;
    QMU = 17.0*CO/100;
    QAD = 5.0 *CO/100;
    QSK = 5.0 *CO/100;
    QSP = 3.0 *CO/100;
    QPA = 1.0 *CO/100;
    QLI = 25.5*CO/100;
    QST = 1.0 *CO/100;
    QGU = 14.0*CO/100;
    QHA = QLI - (QSP + QPA + QST + QGU); # Hepatic artery blood flow
    QBO = 5.0 *CO/100;
    QKI = 19.0*CO/100;
    QRB = CO - (QHT + QBR + QMU + QAD + QSK + QLI + QBO + QKI);
    QLU = QHT + QBR + QMU + QAD + QSK + QLI + QBO + QKI + QRB;
    
    ## Organs' volumes = organs' weights / organs' density
    VLU = (0.76 *WT/100)/1.051;
    VHT = (0.47 *WT/100)/1.030;
    VBR = (2.00 *WT/100)/1.036;
    VMU = (40.00*WT/100)/1.041;
    VAD = (21.42*WT/100)/0.916;
    VSK = (3.71 *WT/100)/1.116;
    VSP = (0.26 *WT/100)/1.054;
    VPA = (0.14 *WT/100)/1.045;
    VLI = (2.57 *WT/100)/1.040;
    VST = (0.21 *WT/100)/1.050;
    VGU = (1.44 *WT/100)/1.043;
    VBO = (14.29*WT/100)/1.990;
    VKI = (0.44 *WT/100)/1.050;
    VAB = (2.81 *WT/100)/1.040;
    VVB = (5.62 *WT/100)/1.040;
    VRB = (3.86 *WT/100)/1.040;
    
    ## Fixed parameters
    BP = 0.61;      # Blood:plasma partition coefficient
    fup = 0.028;    # Fraction unbound in plasma
    fub = fup/BP;   # Fraction unbound in blood
    
    KbLU = exp(0.8334);
    KbHT = exp(1.1205);
    KbSK = exp(-.5238);
    KbSP = exp(0.3224);
    KbPA = exp(0.3224);
    KbLI = exp(1.7604);
    KbST = exp(0.3224);
    KbGU = exp(1.2026);
    KbKI = exp(1.3171);
    
    
    ##-----------------------------------------
    S15 = VVB*BP/1000;
    C15 = Venous_Blood/S15
    lnC15 = log(C15);
    
    ##-----------------------------------------
    d/dt(Lungs) = QLU*(Venous_Blood/VVB - Lungs/KbLU/VLU);
    d/dt(Heart) = QHT*(Arterial_Blood/VAB - Heart/KbHT/VHT);
    d/dt(Brain) = QBR*(Arterial_Blood/VAB - Brain/KbBR/VBR);
    d/dt(Muscles) = QMU*(Arterial_Blood/VAB - Muscles/KbMU/VMU);
    d/dt(Adipose) = QAD*(Arterial_Blood/VAB - Adipose/KbAD/VAD);
    d/dt(Skin) = QSK*(Arterial_Blood/VAB - Skin/KbSK/VSK);
    d/dt(Spleen) = QSP*(Arterial_Blood/VAB - Spleen/KbSP/VSP);
    d/dt(Pancreas) = QPA*(Arterial_Blood/VAB - Pancreas/KbPA/VPA);
    d/dt(Liver) = QHA*Arterial_Blood/VAB + QSP*Spleen/KbSP/VSP + QPA*Pancreas/KbPA/VPA + QST*Stomach/KbST/VST + QGU*Gut/KbGU/VGU - CLint*fub*Liver/KbLI/VLI - QLI*Liver/KbLI/VLI;
    d/dt(Stomach) = QST*(Arterial_Blood/VAB - Stomach/KbST/VST);
    d/dt(Gut) = QGU*(Arterial_Blood/VAB - Gut/KbGU/VGU);
    d/dt(Bones) = QBO*(Arterial_Blood/VAB - Bones/KbBO/VBO);
    d/dt(Kidneys) = QKI*(Arterial_Blood/VAB - Kidneys/KbKI/VKI);
    d/dt(Arterial_Blood) = QLU*(Lungs/KbLU/VLU - Arterial_Blood/VAB);
    d/dt(Venous_Blood) = QHT*Heart/KbHT/VHT + QBR*Brain/KbBR/VBR + QMU*Muscles/KbMU/VMU + QAD*Adipose/KbAD/VAD + QSK*Skin/KbSK/VSK + QLI*Liver/KbLI/VLI + QBO*Bones/KbBO/VBO + QKI*Kidneys/KbKI/VKI + QRB*Rest_of_Body/KbRB/VRB - QLU*Venous_Blood/VVB;
    d/dt(Rest_of_Body) = QRB*(Arterial_Blood/VAB - Rest_of_Body/KbRB/VRB);
    
    
    lnC15 ~ add(add.err)
  })
}

# read the data
dat <- read.csv("data/PBPK_data.csv")

# run the model
fit <- nlmixr(pbpk, dat, est="saem")

# -----------------------------------------
# 1. Using shinyMixR in interactive session
library(shinyMixR)

# the model is defined in a separate file. information regarding models and data is
# maintained in a project object which is automatically loaded when a model is submitted
# models are submitted by default in a separate R session
run_nmx("run1")

# Progress can be read from external file
readLines("shinyMixR/temp/run1.prog.txt")

# -------------------------------
# 1. Using the shinyMixR interface

# the interface can be opened and model(s) can be submitted in run model widget
# Within this widget also the progress can be assessed
# -- Be aware that the same model is not already running interactively --
run_shinymixr()

# PART 2. ANALYSING THE RESULTS
library(xpose.nlmixr)

# ------------------------------
# 1. Using xpose.nlmixr directly 
xpdb <- xpose_data_nlmixr(fit)

dv_vs_pred(xpdb)
dv_vs_ipred(xpdb)
res_vs_pred(xpdb)
res_vs_idv(xpdb)
prm_vs_iteration(xpdb)
absval_res_vs_idv(xpdb, res = 'IWRES')
absval_res_vs_pred(xpdb, res = 'IWRES')
ind_plots(xpdb, nrow=3, ncol=4)
res_distrib(xpdb)
nlmixr::vpc(fit,nsim=500, show=list(obs_dv=T), bins = c(0, 2, 4, 6, 8, 10, 20, 30, 40, 50))

# Results can be exported by using for example pdf(file="results.pdf") ... dev.off()

# ------------------------------------------------------
# 1. Using xpose.nlmixr/shinyMixr in interactive session
res      <- readRDS("shinyMixR/run1.res.rds")
xpdb2    <- xpose_data_nlmixr(res)

gof_plot(res)             # combine multiple GOF at once
prm_vs_iteration(xpdb2)   # xpose.nlmixr functions can be used directly
fit_plot(res,type="user") # "default ggplot" output can be created


# Results can be exported by the function, using the R3port package or with pdf() function e.g.
# gof_plot(res,outnm="gofplot.tex",mdlnm="run1")
# pl <- prm_vs_iteration(xpdb2); R3port::ltx_plot(pl,out="plot.tex")
# pdf("results.pdf"); fit_plot(res); dev.off()

# -----------------------------------------
# 2. Using xpose.nlmixr/shinyMixr interface
# There are widgets for a few default plots, user scripts are possible in the script widget
# plots are by default saved in the analyis folder and made available in the interface
run_shinymixr()

# be aware that this example runs for ~ 6.5 min. on a reasonably fast system: rowSums(res$time)/60
nlmixr::vpc(res,nsim=500,show=list(obs_dv=T),bins = c(0, 2, 4, 6, 8, 10, 20, 30, 40, 50))

library(vpc)
library(nlmixr)

res      <- readRDS("shinyMixR/run1.res.rds")
vpc.ui(res,500,show=list(obs_dv=T) )


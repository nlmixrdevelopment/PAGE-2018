run1 <- function() {
  data = "data_nimo"
  desc = "Case 1 Page course"
  ref  = ""
  imp  = 1
  est  = "saem"
  control<-list()

  ini({
    # Add initial estimates here
  })
  model({
    # Add model here
  })
}

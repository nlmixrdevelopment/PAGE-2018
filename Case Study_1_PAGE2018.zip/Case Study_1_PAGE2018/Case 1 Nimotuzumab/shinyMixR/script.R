# nlmixr course PAGE2018
# Case Example 1: Nimotuzumab
# Author: Mirjam Trame
# This script shows the various ways of running and analysing the case model.

# PART 1. RUNNING THE MODEL

# ------------------------
# 1. Using nlmixr directly
library(nlmixr)

# define the model
nimo <- function() {
  ini({
    ## Note that the UI can take expressions
    ## Also note that these initial estimates should be provided on the log-scale
    tcl <- log(0.001)
    tv1 <- log(1.45)
    tQ <- log(0.004)
    tv2 <- log(44)
    tkss <- log(12)
    tkint <- log(0.3)
    tksyn <- log(1)
    tkdeg <- log(7)
    ## Initial estimates should be high for SAEM ETAs
    eta.cl  ~ 2
    eta.v1  ~ 2
    eta.kss ~ 2
    ##  Also true for additive error (also ignored in SAEM)
    add.err <- 10
  })
  model({
    cl <- exp(tcl + eta.cl)
    v1 <- exp(tv1 + eta.v1)
    Q  <- exp(tQ)
    v2 <- exp(tv2)
    kss <- exp(tkss + eta.kss)
    kint <- exp(tkint)
    ksyn <- exp(tksyn)
    kdeg <- exp(tkdeg)

    k <- cl/v1
    k12 <- Q/v1
    k21 <- Q/v2

    eff(0) <- ksyn/kdeg ##initializing compartment

    ## Concentration is calculated
    conc = 0.5*(central/v1-eff-kss)+0.5*sqrt((central/v1-eff-kss)**2+4*kss*central/v1)

    d/dt(central)  = -(k+k12)*conc*v1+k21*peripheral-kint*eff*conc*v1/(kss+conc)
    d/dt(peripheral) = k12*conc*v1-k21*peripheral  ##Free Drug second compartment amount
    d/dt(eff) = ksyn - kdeg*eff - (kint-kdeg)*conc*eff/(kss+conc)

    IPRED=log(conc)

    IPRED ~ add(add.err)
  })
}

# read the data
dat <- read.csv("data/data_nimo.csv")

# run the model
fit <- nlmixr(nimo, dat, est="saem")

# -----------------------------------------
# 1. Using shinyMixR in interactive session
library(shinyMixR)

# the model is defined in a separate file. information regarding models and data is
# maintained in a project object which is automatically loaded when a model is submitted
# models are submitted by default in a separate R session
run_nmx("run1")

# Progress can be read from external file
readLines("shinyMixR/temp/run1.prog.txt")

# -------------------------------
# 1. Using the shinyMixR interface

# the interface can be opened and model(s) can be submitted in run model widget
# Within this widget also the progress can be assessed
# -- Be aware that the same model is not already running interactively --
run_shinymixr()

# PART 2. ANALYSING THE RESULTS
library(xpose.nlmixr)

# ------------------------------
# 1. Using xpose.nlmixr directly
xpdb <- xpose_data_nlmixr(fit)

dv_vs_pred(xpdb)
dv_vs_ipred(xpdb)
res_vs_pred(xpdb)
res_vs_idv(xpdb)
prm_vs_iteration(xpdb)
absval_res_vs_idv(xpdb, res = 'IWRES')
absval_res_vs_pred(xpdb, res = 'IWRES')
ind_plots(xpdb, nrow=3, ncol=4)
res_distrib(xpdb)
nlmixr::vpc(fit,nsim=500, show=list(obs_dv=T))

# Results can be exported by using for example pdf(file="results.pdf") ... dev.off()

# ------------------------------------------------------
# 1. Using xpose.nlmixr/shinyMixr in interactive session
res      <- readRDS("shinyMixR/run1.res.rds")
xpdb2    <- xpose_data_nlmixr(res)

gof_plot(res)             # combine multiple GOF at once
prm_vs_iteration(xpdb2)   # xpose.nlmixr functions can be used directly
fit_plot(res,type="user") # "default ggplot" output can be created

# Results can be exported by the function, using the R3port package or with pdf() function e.g.
# gof_plot(res,outnm="gofplot.tex",mdlnm="run1")
# pl <- prm_vs_iteration(xpdb2); R3port::ltx_plot(pl,out="plot.tex")
# pdf("results.pdf"); fit_plot(res); dev.off()

# -----------------------------------------
# 2. Using xpose.nlmixr/shinyMixr interface
# There are widgets for a few default plots, user scripts are possible in the script widget
# plots are by default saved in the analyis folder and made available in the interface
run_shinymixr()

# be aware that this example runs for ~ 10 min. on a reasonably fast system: rowSums(fit$time)/60


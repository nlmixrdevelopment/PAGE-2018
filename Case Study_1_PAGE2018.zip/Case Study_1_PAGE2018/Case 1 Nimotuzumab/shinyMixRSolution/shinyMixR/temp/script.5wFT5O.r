library(nlmixr)
options(keep.source = TRUE)
if(!exists("data_nimo", envir=.GlobalEnv)) {
  if(file.exists("./data/data_nimo.rds")){
    data_nlm <- readRDS("./data/data_nimo.rds")
  }else if(file.exists("./data/data_nimo.csv")){
    data_nlm <- read.csv("./data/data_nimo.csv")
  }
}else{
  data_nlm <- data_nimo
}
source("/Users/richard/Documents/Rpackages/shinyMixR/Case1.Page/shinyMixRSolution/models/run1.r")
setwd("shinyMixR/temp")
modres <- try(nlmixr(run1, data=data_nlm, est="saem",control=list()))

if(length(class(modres))>1 && class(modres)!="try-error"){
  saveRDS(modres,file="../run1.res.rds")
  saveRDS(list(OBJF=modres$objective,partbl=modres$par.fixed,omega=modres$omega,
               tottime=rowSums(modres$time)),file="../run1.ressum.rds")
}


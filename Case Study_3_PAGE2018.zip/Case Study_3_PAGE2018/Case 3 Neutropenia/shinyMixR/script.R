# nlmixr course PAGE2018
# Case Example 3: Neutropenia
# Author: Yuan Xiong
# This script shows the various ways of running and analysing the case model.

# PART 1. RUNNING THE MODEL

# ------------------------
# 1. Using nlmixr directly 
library(nlmixr)

# define the model
wbc <- function() {
  ini({
    ## Note that the UI can take expressions
    ## Also note that these initial estimates should be provided on the log-scale
    log_CIRC0 <- log(7.21)
    log_MTT <- log(124)
    log_SLOPU <- log(28.9)
    log_GAMMA <- log(0.239)
    ## Initial estimates should be high for SAEM ETAs
    eta.CIRC0  ~ .1
    eta.MTT  ~ .03
    eta.SLOPU ~ .2
    ##  Also true for additive error (also ignored in SAEM)
    prop.err <- 10
  })
  model({
    CIRC0 =  exp(log_CIRC0 + eta.CIRC0) 
    MTT =  exp(log_MTT + eta.MTT)
    SLOPU =  exp(log_SLOPU + eta.SLOPU)
    GAMMA = exp(log_GAMMA)
    
    # PK parameters from input dataset
    CL = CLI;   
    V1 = V1I;   
    V2 = V2I;   
    Q = 204;     
    
    CONC = A_centr/V1;
    
    # PD parameters
    NN = 3;
    KTR = (NN + 1)/MTT;
    EDRUG = 1 - SLOPU * CONC; 
    FDBK = (CIRC0 / A_circ)^GAMMA;  
    
    CIRC = A_circ;
    
    A_prol(0) = CIRC0;
    A_tr1(0) = CIRC0;
    A_tr2(0) = CIRC0;
    A_tr3(0) = CIRC0;
    A_circ(0) = CIRC0;
    
    d/dt(A_centr) = A_periph * Q/V2 - A_centr * (CL/V1 + Q/V1);
    d/dt(A_periph) = A_centr * Q/V1 - A_periph * Q/V2;
    d/dt(A_prol) = KTR * A_prol * EDRUG * FDBK - KTR * A_prol;
    d/dt(A_tr1) = KTR * A_prol - KTR * A_tr1;
    d/dt(A_tr2) = KTR * A_tr1 - KTR * A_tr2;
    d/dt(A_tr3) = KTR * A_tr2 - KTR * A_tr3;
    d/dt(A_circ) = KTR * A_tr3 - KTR * A_circ;
    
    CIRC ~ prop(prop.err)
  })
}

# read the data
dat <- read.csv("data/data_wbc.csv")

# run the model
fit <- nlmixr(wbc, dat, est="saem")

# -----------------------------------------
# 1. Using shinyMixR in interactive session
library(shinyMixR)

# the model is defined in a separate file. information regarding models and data is
# maintained in a project object which is needed to run models 
# models are submitted by default in a separate R session
run_nmx("run1",proj)

# Progress can be read from external file
cat(readLines("shinyMixR/temp/run1.prog.txt"),sep="\n")

# -------------------------------
# 1. Using the shinyMixR interface

# the interface can be opened and model(s) can be submitted in run model widget
# Within this widget also the progress can be assessed
# -- Be aware that the same model is not already running interactively --
run_shinymixr()

# PART 2. ANALYSING THE RESULTS
library(xpose.nlmixr)

# ------------------------------
# 1. Using xpose.nlmixr directly 
xpdb <- xpose_data_nlmixr(fit)

dv_vs_pred(xpdb)
dv_vs_ipred(xpdb)
res_vs_pred(xpdb)
res_vs_idv(xpdb)
prm_vs_iteration(xpdb)
absval_res_vs_idv(xpdb, res = 'IWRES')
absval_res_vs_pred(xpdb, res = 'IWRES')
ind_plots(xpdb, nrow=3, ncol=4)
res_distrib(xpdb)
nlmixr::vpc(fit,nsim=500, n_bins=10, show=list(obs_dv=T))

# Results can be exported by using for example pdf(file="results.pdf") ... dev.off()

# ------------------------------------------------------
# 1. Using xpose.nlmixr/shinyMixr in interactive session
library(xpose.nlmixr)
res      <- readRDS("shinyMixR/run1.res.rds")
xpdb2    <- xpose_data_nlmixr(res)

gof_plot(res)             # combine multiple GOF at once
prm_vs_iteration(xpdb2)   # xpose.nlmixr functions can be used directly
fit_plot(res,type="user") # "default ggplot" output can be created

# Results can be exported by the function, using the R3port package or with pdf() function e.g.
# gof_plot(res,outnm="gofplot.tex",mdlnm="run1")
# pl <- prm_vs_iteration(xpdb2); R3port::ltx_plot(pl,out="plot.tex")
# pdf("results.pdf"); fit_plot(res); dev.off()

# -----------------------------------------
# 2. Using xpose.nlmixr/shinyMixr interface
# There are widgets for a few default plots, user scripts are possible in the script widget
# plots are by default saved in the analyis folder and made available in the interface
run_shinymixr()

# be aware that this example runs for ~ 10 min. on a reasonably fast system: rowSums(fit$time)/60



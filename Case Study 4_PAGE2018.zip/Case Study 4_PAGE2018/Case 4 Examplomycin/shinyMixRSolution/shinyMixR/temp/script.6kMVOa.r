library(nlmixr)
options(keep.source = TRUE)
if(!exists("examplomycin", envir=.GlobalEnv)) {
  if(file.exists("./data/examplomycin.rds")){
    data_nlm <- readRDS("./data/examplomycin.rds")
  }else if(file.exists("./data/examplomycin.csv")){
    data_nlm <- read.csv("./data/examplomycin.csv")
  }
}else{
  data_nlm <- examplomycin
}
source("/Users/richard/Documents/Rpackages/shinyMixR/Case4.Page/shinyMixRSolution/models/run8.r")
setwd("shinyMixR/temp")
modres <- try(nlmixr(run8, data=data_nlm, est="saem",control=list()))

if(length(class(modres))>1 && class(modres)!="try-error"){
  saveRDS(modres,file="../run8.res.rds")
  saveRDS(list(OBJF=modres$objective,partbl=modres$par.fixed,omega=modres$omega,
               tottime=rowSums(modres$time)),file="../run8.ressum.rds")
}


run8 <- function() {
  data = "examplomycin"
  desc = "Two cmt V2.SEX CL.WT closed"
  ref = ""
  imp = 1
  est = "saem"
  control <- saemControl(pnlsTol = 0.1)
  ini({
    tka    <- log(1.14) 
    tcl    <- log(0.0190) 
    tv2    <- log(2.12) 
    tv3    <- log(20.4) 
    tq     <- log(0.383) 
    wteff  <- 0.35 
    sexeff <- -0.2
    eta.ka ~ 0.1 
    eta.cl ~ 0.1 
    eta.v2 ~ 0.1 
    eta.v3 ~ 0.1 
    eta.q ~ 0.1 
    prop.err <- 0.075
  }) 
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + wteff*log(WT/70) + eta.cl) 
    v2 <- exp(tv2 + sexeff*(SEX) + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    q <- exp(tq + eta.q)
    linCmt() ~ prop(prop.err)
  })
}

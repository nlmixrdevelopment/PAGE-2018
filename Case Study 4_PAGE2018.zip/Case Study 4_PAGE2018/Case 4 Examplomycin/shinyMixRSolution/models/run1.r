run1 <- function() {
  data = "examplomycin"
  desc = "One cmt base model"
  ref  = ""
  imp  = 1
  est  = "saem"
  control<-list()
  ini({
    tka <- log(1.5) 
    tcl <- log(1.5) 
    tv <- log(3) 
    eta.ka ~ 1 
    eta.cl ~ 1 
    eta.v ~ 1 
    add.err <- 0.1
  }) 
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + eta.cl)
    v <- exp(tv + eta.v)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v * center 
    cp = center / v
    cp ~ add(add.err) 
  })
}

run4 <- function() {
  data = "examplomycin"
  desc = "Three cmt model"
  ref = ""
  imp = 1
  est = "saem"
  control<-list()
  ini({
    tka <- log(1.42) 
    tcl <- log(0.044) 
    tv2 <- log(2) 
    tv3 <- log(10) 
    tv4 <- log(10)
    tq2 <- log(0.5)
    tq3 <- log(0.5)
    eta.ka ~ 0.1 
    eta.cl ~ 0.1 
    eta.v2 ~ 0.1 
    eta.v3 ~ 0.1 
    eta.v4 ~ 0.1 
    eta.q2 ~ 0.1 
    eta.q3 ~ 0.1 
    prop.err <- 0.075
  }) 
  model({
    ka <- exp(tka + eta.ka)
    cl <- exp(tcl + eta.cl)
    v2 <- exp(tv2 + eta.v2)
    v3 <- exp(tv3 + eta.v3)
    v4 <- exp(tv4 + eta.v4)
    q2 <- exp(tq2 + eta.q2)
    q3 <- exp(tq3 + eta.q3)
    d/dt(depot) = -ka * depot
    d/dt(center) = ka * depot - cl / v2 * center + q2/v3 * periph1 - q2/v2 * center + q3/v4 * periph2 - q3/v2 * center
    d/dt(periph1) = q2/v2 * center - q2/v3 * periph1
    d/dt(periph2) = q3/v2 * center - q3/v4 * periph2
    cp = center / v2
    cp ~ prop(prop.err)
  })
}
